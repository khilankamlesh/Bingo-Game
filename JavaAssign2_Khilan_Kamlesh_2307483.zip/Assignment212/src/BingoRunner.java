public class BingoRunner {
    public static void main(String[] args) {
        BingoController bingo = new BingoController();
        bingo.run();
        System.out.println(Toolkit.GOODBYEMESSAGE);
    }
}
